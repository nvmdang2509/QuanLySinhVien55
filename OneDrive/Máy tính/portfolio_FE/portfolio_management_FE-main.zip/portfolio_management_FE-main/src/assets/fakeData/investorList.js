export const investorList = [
    {
        investor_code: "NEUIND00001",
        injection_date: "12/12/2012",
        status: {
            contact_status: true,
            contact_end_date: "12/12/2012",
            last_update: "12/12/2012",
        },
        fund: {
            initial: 20833,
            current: 25291,
            profit: 4458
        },
        performance: {
            roi: 21.40,
            anulized_roi: 223.16
        }
    },
    {
        investor_code: "NEUIND00002",
        injection_date: "12/12/2012",
        status: {
            contact_status: true,
            contact_end_date: "12/12/2012",
            last_update: "12/12/2012",
        },
        fund: {
            initial: 20833,
            current: 25291,
            profit: 4458
        },
        performance: {
            roi: 21.40,
            anulized_roi: 223.16
        }
    },
    {
        investor_code: "NEUIND00003",
        injection_date: "12/12/2012",
        status: {
            contact_status: true,
            contact_end_date: "12/12/2012",
            last_update: "12/12/2012",
        },
        fund: {
            initial: 20833,
            current: 25291,
            profit: 4458
        },
        performance: {
            roi: 21.40,
            anulized_roi: 223.16
        }
    },
    {
        investor_code: "NEUIND00004",
        injection_date: "12/12/2012",
        status: {
            contact_status: true,
            contact_end_date: "12/12/2012",
            last_update: "12/12/2012",
        },
        fund: {
            initial: 20833,
            current: 25291,
            profit: 4458
        },
        performance: {
            roi: 21.40,
            anulized_roi: 223.16
        }
    },
    {
        investor_code: "NEUIND00005",
        injection_date: "12/12/2012",
        status: {
            contact_status: true,
            contact_end_date: "12/12/2012",
            last_update: "12/12/2012",
        },
        fund: {
            initial: 20833,
            current: 25291,
            profit: 4458
        },
        performance: {
            roi: 21.40,
            anulized_roi: 223.16
        }
    },
    {
        investor_code: "NEUIND00006",
        injection_date: "12/12/2012",
        status: {
            contact_status: true,
            contact_end_date: "12/12/2012",
            last_update: "12/12/2012",
        },
        fund: {
            initial: 20833,
            current: 25291,
            profit: 4458
        },
        performance: {
            roi: 21.40,
            anulized_roi: 223.16
        }
    }
]